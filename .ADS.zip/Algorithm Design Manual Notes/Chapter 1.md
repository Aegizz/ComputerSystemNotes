
#### Algorithm is a procedure to achieve a specific task.
An algorithmic problem is specified by describing the complete set of instances it must work on and of its output after running one of these instances.

#Example 
##### Problem: Sorting
##### Input: A sequence of n keys, $$a_1, ..... , a_n.$$
##### Output: The permutation (reordering) of the input sequence such that $$a_1  \le a_2 \le ..... \le a_{n-1} \leq a_n $$
##### Instance of sorting could be numbers or an array of names. Determining you are dealing with a general problem is your first step towards solving it.

[[Insertion Sort]]

